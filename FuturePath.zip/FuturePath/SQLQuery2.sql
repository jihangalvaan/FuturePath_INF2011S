﻿USE FuturePathDB;
GO

INSERT INTO GradeLevel (GradeName)
VALUES
('Grade 11'),
('Grade 12');

INSERT INTO Subject (SubjectName)
VALUES
('Mathematics'),
('Mathematical Literacy'),
('Physical Sciences'),
('Life Sciences'),
('English'),
('Afrikaans'),
('Information Technology'),
('Accounting'),
('Business Studies'),
('Economics'),
('Geography'),
('History'),
('Life Orientation'),
('Computer Applications Technology'),
('Consumer Studies'),
('Design');

INSERT INTO Faculty (FacultyName)
VALUES
('Science and Engineering'),
('Commerce'),
('Humanities'),
('Health Sciences'),
('Information Technology');

INSERT INTO InterestCategory (CategoryName)
VALUES
('Technology'),
('Science'),
('Business'),
('People and Society'),
('Creative');

INSERT INTO InterestQuestion
    (InterestCategoryID, QuestionText)
VALUES
(1, 'I enjoy working with computers and technology.'),
(1, 'I enjoy solving technical problems.'),
(2, 'I enjoy learning about science.'),
(2, 'I enjoy conducting experiments and analysing results.'),
(3, 'I enjoy working with money and business information.'),
(3, 'I am interested in starting or managing a business.'),
(4, 'I enjoy helping and communicating with people.'),
(5, 'I enjoy creating and designing new ideas.');
GO