﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using FuturePath.DataAccess.Repositories;
using FuturePath.Entities.Models;

namespace FuturePath.BusinessLogic
{
    public class InterestService
    {
        private InterestRepository interestRepository =
            new InterestRepository();

        public List<InterestCategory> GetCategories()
        {
            return interestRepository.GetAllCategories();
        }

        public List<InterestQuestion> GetQuestions()
        {
            return interestRepository.GetAllQuestions();
        }

        public bool SaveResponse(
            LearnerInterestResponse response)
        {
            if (response == null)
            {
                return false;
            }

            if (response.LearnerID <= 0)
            {
                return false;
            }

            if (response.InterestQuestionID <= 0)
            {
                return false;
            }

            if (response.ResponseScore < 1 ||
                response.ResponseScore > 5)
            {
                return false;
            }

            interestRepository.SaveLearnerResponse(
                response);

            return true;
        }

        public List<LearnerInterestResponse>
            GetLearnerResponses(int learnerID)
        {
            if (learnerID <= 0)
            {
                return new List<LearnerInterestResponse>();
            }

            return interestRepository.GetLearnerResponses(
                learnerID);
        }

        public List<DegreeInterestMapping>
            GetDegreeInterestMappings(
                int degreeProgrammeID)
        {
            if (degreeProgrammeID <= 0)
            {
                return new List<DegreeInterestMapping>();
            }

            return interestRepository
                .GetDegreeInterestMappings(
                    degreeProgrammeID);
        }
    }
}