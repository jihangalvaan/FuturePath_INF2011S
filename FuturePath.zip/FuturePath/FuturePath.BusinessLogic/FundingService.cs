﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using FuturePath.DataAccess.Repositories;
using FuturePath.Entities.Models;

namespace FuturePath.BusinessLogic
{
    public class FundingService
    {
        private FundingRepository fundingRepository =
            new FundingRepository();

        public List<FundingOption> GetFundingOptions()
        {
            return fundingRepository
                .GetActiveFundingOptions();
        }

        public FundingOption GetFundingOption(
            int fundingOptionID)
        {
            if (fundingOptionID <= 0)
            {
                return null;
            }

            return fundingRepository
                .GetFundingOptionByID(
                    fundingOptionID);
        }

        public string GetFundingGuidance(
            FundingOption fundingOption)
        {
            if (fundingOption == null)
            {
                return
                    "No funding information is currently " +
                    "available.";
            }

            return
                fundingOption.FundingName +
                ": " +
                fundingOption.Description +
                " Funding information is provided as " +
                "guidance only. The learner should confirm " +
                "current eligibility and application " +
                "requirements with the funding provider.";
        }
    }
}
