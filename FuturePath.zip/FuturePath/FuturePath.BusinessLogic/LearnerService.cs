﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using FuturePath.DataAccess.Repositories;
using FuturePath.Entities.Models;

namespace FuturePath.BusinessLogic
{
    public class LearnerService
    {
        private LearnerRepository learnerRepository =
            new LearnerRepository();

        public bool AddLearner(Learner learner)
        {
            if (learner == null)
            {
                return false;
            }

            if (string.IsNullOrWhiteSpace(learner.FirstName))
            {
                return false;
            }

            if (string.IsNullOrWhiteSpace(learner.Surname))
            {
                return false;
            }

            if (learner.GradeLevelID <= 0)
            {
                return false;
            }

            if (string.IsNullOrWhiteSpace(learner.School))
            {
                return false;
            }

            if (string.IsNullOrWhiteSpace(learner.ContactNumber))
            {
                return false;
            }

            learnerRepository.AddLearner(learner);

            return true;
        }

        public Learner GetLearnerByID(int learnerID)
        {
            if (learnerID <= 0)
            {
                return null;
            }

            return learnerRepository.GetLearnerByID(
                learnerID);
        }

        public List<Learner> GetAllLearners()
        {
            return learnerRepository.GetAllLearners();
        }
    }
}