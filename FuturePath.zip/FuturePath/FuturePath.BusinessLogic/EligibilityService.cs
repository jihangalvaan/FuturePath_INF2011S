﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using FuturePath.DataAccess.Repositories;
using FuturePath.Entities.Models;

namespace FuturePath.BusinessLogic
{
    public class EligibilityService
    {
        private DegreeRepository degreeRepository =
            new DegreeRepository();

        private LearnerRepository learnerRepository =
            new LearnerRepository();

        private SubjectRepository subjectRepository =
            new SubjectRepository();

        public RecommendationResult
            CalculateEligibility(
                int learnerID,
                int degreeProgrammeID,
                int advisorySessionID)
        {
            Learner learner =
                learnerRepository.GetLearnerByID(learnerID);

            DegreeProgramme programme =
                degreeRepository.GetDegreeProgrammeByID(
                    degreeProgrammeID);

            List<ProgrammeRequirement> requirements =
                degreeRepository.GetProgrammeRequirements(
                    degreeProgrammeID);

            if (learner == null)
            {
                return CreateResult(
                    advisorySessionID,
                    "More Information Needed",
                    0,
                    "Learner information could not be found.",
                    "");
            }

            if (programme == null)
            {
                return CreateResult(
                    advisorySessionID,
                    "More Information Needed",
                    0,
                    "The selected degree programme could not be found.",
                    "");
            }

            if (requirements.Count == 0)
            {
                return CreateResult(
                    advisorySessionID,
                    "More Information Needed",
                    0,
                    "No programme requirements are currently available.",
                    "");
            }

            Dictionary<int, decimal> learnerMarks =
                GetLearnerMarks(learnerID);

            int requirementsMet = 0;
            int requirementsMissing = 0;

            StringBuilder academicGaps =
                new StringBuilder();

            foreach (ProgrammeRequirement requirement
                in requirements)
            {
                decimal learnerMark;

                if (!learnerMarks.TryGetValue(
                    requirement.SubjectID,
                    out learnerMark))
                {
                    requirementsMissing++;

                    Subject subject =
                        subjectRepository.GetSubjectByID(
                            requirement.SubjectID);

                    string subjectName =
                        subject != null
                            ? subject.SubjectName
                            : "Required subject";

                    academicGaps.Append(
                        subjectName +
                        " mark is missing. Required minimum: " +
                        requirement.MinimumMark +
                        ". ");

                    continue;
                }

                if (learnerMark >= requirement.MinimumMark)
                {
                    requirementsMet++;
                }
                else
                {
                    requirementsMissing++;

                    Subject subject =
                        subjectRepository.GetSubjectByID(
                            requirement.SubjectID);

                    string subjectName =
                        subject != null
                            ? subject.SubjectName
                            : "Required subject";

                    academicGaps.Append(
                        subjectName +
                        " requires " +
                        requirement.MinimumMark +
                        "% but learner has " +
                        learnerMark +
                        "%. ");
                }
            }

            decimal score =
                (decimal)requirementsMet /
                requirements.Count * 100;

            string outcome;
            string reason;

            if (requirementsMissing == 0)
            {
                outcome = "Strong Match";

                reason =
                    "The learner meets all recorded academic " +
                    "requirements for " +
                    programme.ProgrammeName +
                    ".";
            }
            else if (requirementsMet > 0 &&
                     requirementsMissing < requirements.Count)
            {
                outcome = "Possible Match";

                reason =
                    "The learner meets some of the recorded " +
                    "academic requirements for " +
                    programme.ProgrammeName +
                    ", but has academic gaps.";
            }
            else if (requirementsMissing == requirements.Count &&
                     academicGaps.Length > 0)
            {
                outcome = "Not Currently Eligible";

                reason =
                    "The learner does not currently meet the " +
                    "recorded academic requirements for " +
                    programme.ProgrammeName +
                    ".";
            }

            else
            {
                outcome = "More Information Needed";

                reason =
                    "More learner academic information is required " +
                    "to determine eligibility.";
            }

            return CreateResult(
                advisorySessionID,
                outcome,
                score,
                reason,
                academicGaps.ToString());
        }

        private Dictionary<int, decimal> GetLearnerMarks(
     int learnerID)
        {
            Dictionary<int, decimal> marks =
                new Dictionary<int, decimal>();

            List<LearnerSubject> learnerSubjects =
                learnerRepository.GetLearnerSubjects(learnerID);

            foreach (LearnerSubject learnerSubject
                in learnerSubjects)
            {
                if (!marks.ContainsKey(
                    learnerSubject.SubjectID))
                {
                    marks.Add(
                        learnerSubject.SubjectID,
                        learnerSubject.Mark);
                }
            }

            return marks;
        }

        private RecommendationResult CreateResult(
            int advisorySessionID,
            string outcome,
            decimal score,
            string reason,
            string academicGap)
        {
            RecommendationResult result =
                new RecommendationResult();

            result.AdvisorySessionID =
                advisorySessionID;

            result.Outcome = outcome;

            result.RecommendationScore =
                score;

            result.Reason = reason;

            result.AcademicGap =
                academicGap;

            return result;
        }
    }
}
