﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using FuturePath.Entities.Models;

namespace FuturePath.BusinessLogic
{
    public class RecommendationService
    {
        public string GetRecommendation(
            RecommendationResult result)
        {
            if (result == null)
            {
                return "More Information Needed";
            }

            if (result.Outcome == "Strong Match")
            {
                return
                    "This programme is a strong academic match " +
                    "based on the recorded learner results.";
            }

            if (result.Outcome == "Possible Match")
            {
                return
                    "This programme may be suitable, but the " +
                    "learner should review the identified " +
                    "academic gaps.";
            }

            if (result.Outcome == "Not Currently Eligible")
            {
                return
                    "The learner does not currently meet the " +
                    "recorded requirements. Consider addressing " +
                    "the academic gaps or reviewing alternative " +
                    "programmes.";
            }

            return
                "More information is required before a " +
                "recommendation can be made.";
        }

        public string GetAcademicGap(
            RecommendationResult result)
        {
            if (result == null)
            {
                return "No academic information is available.";
            }

            if (string.IsNullOrWhiteSpace(
                result.AcademicGap))
            {
                return "No academic gaps were identified.";
            }

            return result.AcademicGap;
        }

        public string GetReason(
            RecommendationResult result)
        {
            if (result == null)
            {
                return "No recommendation result is available.";
            }

            if (string.IsNullOrWhiteSpace(
                result.Reason))
            {
                return "No reason is available.";
            }

            return result.Reason;
        }
    }
}
