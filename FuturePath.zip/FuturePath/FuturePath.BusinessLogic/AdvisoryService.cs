﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using FuturePath.DataAccess.Repositories;
using FuturePath.Entities.Models;

namespace FuturePath.BusinessLogic
{
    public class AdvisoryService
    {
        private AdvisoryRepository advisoryRepository =
            new AdvisoryRepository();

        private EligibilityService eligibilityService =
            new EligibilityService();

        private RecommendationService recommendationService =
            new RecommendationService();

        public RecommendationResult
            CreateAdvisory(
                int learnerID,
                int degreeProgrammeID)
        {
            if (learnerID <= 0)
            {
                return null;
            }

            if (degreeProgrammeID <= 0)
            {
                return null;
            }

            AdvisorySession session =
                new AdvisorySession();

            session.LearnerID = learnerID;

            session.DegreeProgrammeID =
                degreeProgrammeID;

            session.SessionDate =
                DateTime.Now;

            int advisorySessionID =
                advisoryRepository.CreateAdvisorySession(
                    session);

            RecommendationResult result =
                eligibilityService.CalculateEligibility(
                    learnerID,
                    degreeProgrammeID,
                    advisorySessionID);

            advisoryRepository.SaveRecommendationResult(
                result);

            return result;
        }

        public RecommendationResult
            GetAdvisoryResult(
                int advisorySessionID)
        {
            if (advisorySessionID <= 0)
            {
                return null;
            }

            return advisoryRepository
                .GetRecommendationResult(
                    advisorySessionID);
        }

        public string GetRecommendationText(
            RecommendationResult result)
        {
            return recommendationService
                .GetRecommendation(result);
        }

        public string GetReason(
            RecommendationResult result)
        {
            return recommendationService
                .GetReason(result);
        }

        public string GetAcademicGap(
            RecommendationResult result)
        {
            return recommendationService
                .GetAcademicGap(result);
        }
    }
}