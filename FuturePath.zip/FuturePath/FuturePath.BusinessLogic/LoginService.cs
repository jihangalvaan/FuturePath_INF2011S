﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using FuturePath.DataAccess.Repositories;
using FuturePath.Entities.Models;

namespace FuturePath.BusinessLogic
{
    public class LoginService
    {
        private UserRepository userRepository =
            new UserRepository();

        public UserAccount Login(
            string username,
            string password)
        {
            if (string.IsNullOrWhiteSpace(username))
            {
                return null;
            }

            if (string.IsNullOrWhiteSpace(password))
            {
                return null;
            }

            return userRepository.Login(
                username.Trim(),
                password);
        }

        public bool IsLearner(UserAccount user)
        {
            return user != null &&
                   user.Role == "Learner";
        }

        public bool IsCareerAdvisor(UserAccount user)
        {
            return user != null &&
                   user.Role == "Career Advisor";
        }

        public bool IsAdministrator(UserAccount user)
        {
            return user != null &&
                   user.Role == "System Administrator";
        }
    }
}
