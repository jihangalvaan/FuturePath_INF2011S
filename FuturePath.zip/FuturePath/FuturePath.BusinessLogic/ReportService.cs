﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using FuturePath.DataAccess.Repositories;
using FuturePath.Entities.Models;

namespace FuturePath.BusinessLogic
{
    public class ReportService
    {
        private AdvisoryRepository advisoryRepository =
            new AdvisoryRepository();

        public string CreateAdvisorySummary(
            Learner learner,
            DegreeProgramme programme,
            RecommendationResult result)
        {
            if (learner == null ||
                programme == null ||
                result == null)
            {
                return "";
            }

            string summary =
                "FUTURE PATH STUDENT ADVISING SYSTEM" +
                Environment.NewLine +
                Environment.NewLine +
                "LEARNER INFORMATION" +
                Environment.NewLine +
                "Name: " +
                learner.FirstName +
                " " +
                learner.Surname +
                Environment.NewLine +
                "School: " +
                learner.School +
                Environment.NewLine +
                Environment.NewLine +
                "PROGRAMME" +
                Environment.NewLine +
                programme.ProgrammeName +
                Environment.NewLine +
                Environment.NewLine +
                "ADVISORY RESULT" +
                Environment.NewLine +
                "Outcome: " +
                result.Outcome +
                Environment.NewLine +
                "Score: " +
                result.RecommendationScore +
                "%" +
                Environment.NewLine +
                Environment.NewLine +
                "Reason" +
                Environment.NewLine +
                result.Reason +
                Environment.NewLine +
                Environment.NewLine +
                "Academic Gap" +
                Environment.NewLine +
                result.AcademicGap +
                Environment.NewLine +
                Environment.NewLine +
                "Date: " +
                DateTime.Now.ToShortDateString() +
                Environment.NewLine +
                Environment.NewLine +
                "Disclaimer: This advisory result is based on " +
                "the information currently recorded in the " +
                "system. Requirements and funding information " +
                "may change. Funding information is guidance " +
                "only.";

            return summary;
        }

        public bool ExportAdvisorySummary(
            string summary,
            string filePath,
            int advisorySessionID)
        {
            if (string.IsNullOrWhiteSpace(summary))
            {
                return false;
            }

            if (string.IsNullOrWhiteSpace(filePath))
            {
                return false;
            }

            if (advisorySessionID <= 0)
            {
                return false;
            }

            File.WriteAllText(
                filePath,
                summary);

            ExportReport report =
                new ExportReport();

            report.AdvisorySessionID =
                advisorySessionID;

            report.ReportType =
                "Learner Advisory Summary";

            report.ExportDate =
                DateTime.Now;

            report.FilePath =
                filePath;

            advisoryRepository.SaveExportReport(
                report);

            return true;
        }
    }
}
