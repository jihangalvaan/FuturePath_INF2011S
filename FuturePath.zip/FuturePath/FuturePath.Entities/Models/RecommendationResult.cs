﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FuturePath.Entities.Models
{
    public class RecommendationResult
    {
        public int RecommendationResultID { get; set; }

        public int AdvisorySessionID { get; set; }

        public string Outcome { get; set; }

        public decimal RecommendationScore { get; set; }

        public string Reason { get; set; }

        public string AcademicGap { get; set; }
    }
}
