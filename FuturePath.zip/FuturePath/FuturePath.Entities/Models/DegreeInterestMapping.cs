﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FuturePath.Entities.Models
{
    public class DegreeInterestMapping
    {
        public int DegreeInterestMappingID { get; set; }

        public int DegreeProgrammeID { get; set; }

        public int InterestCategoryID { get; set; }
    }
}
