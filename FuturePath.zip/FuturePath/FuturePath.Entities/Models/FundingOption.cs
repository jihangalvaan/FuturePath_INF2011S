﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FuturePath.Entities.Models
{
    public class FundingOption
    {
        public int FundingOptionID { get; set; }

        public string FundingName { get; set; }

        public string FundingType { get; set; }

        public string Description { get; set; }

        public bool IsActive { get; set; }
    }
}
