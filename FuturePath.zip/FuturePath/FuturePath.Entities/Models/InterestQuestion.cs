﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FuturePath.Entities.Models
{
    public class InterestQuestion
    {
        public int InterestQuestionID { get; set; }

        public int InterestCategoryID { get; set; }

        public string QuestionText { get; set; }
    }
}
