﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FuturePath.Entities.Models
{
    public class ExportReport
    {
        public int ExportReportID { get; set; }

        public int AdvisorySessionID { get; set; }

        public string ReportType { get; set; }

        public DateTime ExportDate { get; set; }

        public string FilePath { get; set; }
    }
}
