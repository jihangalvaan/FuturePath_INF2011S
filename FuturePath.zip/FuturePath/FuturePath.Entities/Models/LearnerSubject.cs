﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FuturePath.Entities.Models
{
    public class LearnerSubject
    {
        public int LearnerSubjectID { get; set; }

        public int LearnerID { get; set; }

        public int SubjectID { get; set; }

        public decimal Mark { get; set; }
    }
}
