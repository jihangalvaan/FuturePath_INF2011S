﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FuturePath.Entities.Models
{
    public class DegreeProgramme
    {
        public int DegreeProgrammeID { get; set; }

        public int FacultyID { get; set; }

        public string ProgrammeName { get; set; }

        public bool IsActive { get; set; }
    }
}