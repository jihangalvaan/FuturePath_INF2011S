﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FuturePath.Entities.Models
{
    public class Faculty
    {
        public int FacultyID { get; set; }

        public string FacultyName { get; set; }
    }
}
