﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FuturePath.Entities.Models
{
    public class Learner
    {
        public int LearnerID { get; set; }

        public string FirstName { get; set; }

        public string Surname { get; set; }

        public int GradeLevelID { get; set; }

        public string School { get; set; }

        public string ContactNumber { get; set; }
    }
}
