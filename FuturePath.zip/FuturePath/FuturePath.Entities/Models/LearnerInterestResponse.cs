﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FuturePath.Entities.Models
{
    public class LearnerInterestResponse
    {
        public int LearnerInterestResponseID { get; set; }

        public int LearnerID { get; set; }

        public int InterestQuestionID { get; set; }

        public int ResponseScore { get; set; }
    }
}