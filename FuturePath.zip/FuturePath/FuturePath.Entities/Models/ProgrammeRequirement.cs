﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FuturePath.Entities.Models
{
    public class ProgrammeRequirement
    {
        public int ProgrammeRequirementID { get; set; }

        public int DegreeProgrammeID { get; set; }

        public int SubjectID { get; set; }

        public decimal MinimumMark { get; set; }
    }
}
