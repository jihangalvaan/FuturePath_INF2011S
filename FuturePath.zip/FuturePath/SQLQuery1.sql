﻿CREATE DATABASE FuturePathDB;
GO

USE FuturePathDB;
GO

CREATE TABLE GradeLevel
(
    GradeLevelID INT IDENTITY(1,1) PRIMARY KEY,
    GradeName VARCHAR(20) NOT NULL
);

CREATE TABLE Subject
(
    SubjectID INT IDENTITY(1,1) PRIMARY KEY,
    SubjectName VARCHAR(100) NOT NULL,
    IsActive BIT NOT NULL DEFAULT 1
);

CREATE TABLE Faculty
(
    FacultyID INT IDENTITY(1,1) PRIMARY KEY,
    FacultyName VARCHAR(150) NOT NULL,
    IsActive BIT NOT NULL DEFAULT 1
);

CREATE TABLE DegreeProgramme
(
    DegreeProgrammeID INT IDENTITY(1,1) PRIMARY KEY,
    FacultyID INT NOT NULL,
    DegreeName VARCHAR(200) NOT NULL,
    IsActive BIT NOT NULL DEFAULT 1,

    CONSTRAINT FK_DegreeProgramme_Faculty
        FOREIGN KEY (FacultyID)
        REFERENCES Faculty(FacultyID)
);

CREATE TABLE Learner
(
    LearnerID INT IDENTITY(1,1) PRIMARY KEY,
    FirstName VARCHAR(100) NOT NULL,
    Surname VARCHAR(100) NOT NULL,
    GradeLevelID INT NOT NULL,
    School VARCHAR(150) NOT NULL,
    ContactNumber VARCHAR(30),
    Email VARCHAR(150),

    CONSTRAINT FK_Learner_GradeLevel
        FOREIGN KEY (GradeLevelID)
        REFERENCES GradeLevel(GradeLevelID)
);

CREATE TABLE LearnerSubject
(
    LearnerSubjectID INT IDENTITY(1,1) PRIMARY KEY,
    LearnerID INT NOT NULL,
    SubjectID INT NOT NULL,
    Mark INT NOT NULL,

    CONSTRAINT FK_LearnerSubject_Learner
        FOREIGN KEY (LearnerID)
        REFERENCES Learner(LearnerID),

    CONSTRAINT FK_LearnerSubject_Subject
        FOREIGN KEY (SubjectID)
        REFERENCES Subject(SubjectID),

    CONSTRAINT CK_LearnerSubject_Mark
        CHECK (Mark >= 0 AND Mark <= 100),

    CONSTRAINT UQ_LearnerSubject
        UNIQUE (LearnerID, SubjectID)
);

CREATE TABLE ProgrammeRequirement
(
    ProgrammeRequirementID INT IDENTITY(1,1) PRIMARY KEY,
    DegreeProgrammeID INT NOT NULL,
    SubjectID INT NOT NULL,
    MinimumMark INT NOT NULL,

    CONSTRAINT FK_ProgrammeRequirement_Programme
        FOREIGN KEY (DegreeProgrammeID)
        REFERENCES DegreeProgramme(DegreeProgrammeID),

    CONSTRAINT FK_ProgrammeRequirement_Subject
        FOREIGN KEY (SubjectID)
        REFERENCES Subject(SubjectID),

    CONSTRAINT CK_ProgrammeRequirement_MinimumMark
        CHECK (MinimumMark >= 0 AND MinimumMark <= 100),

    CONSTRAINT UQ_ProgrammeRequirement
        UNIQUE (DegreeProgrammeID, SubjectID)
);

CREATE TABLE InterestCategory
(
    InterestCategoryID INT IDENTITY(1,1) PRIMARY KEY,
    CategoryName VARCHAR(100) NOT NULL,
    IsActive BIT NOT NULL DEFAULT 1
);

CREATE TABLE InterestQuestion
(
    InterestQuestionID INT IDENTITY(1,1) PRIMARY KEY,
    InterestCategoryID INT NOT NULL,
    QuestionText VARCHAR(500) NOT NULL,
    IsActive BIT NOT NULL DEFAULT 1,

    CONSTRAINT FK_InterestQuestion_Category
        FOREIGN KEY (InterestCategoryID)
        REFERENCES InterestCategory(InterestCategoryID)
);

CREATE TABLE DegreeInterestMapping
(
    DegreeInterestMappingID INT IDENTITY(1,1) PRIMARY KEY,
    DegreeProgrammeID INT NOT NULL,
    InterestCategoryID INT NOT NULL,

    CONSTRAINT FK_DegreeInterestMapping_Degree
        FOREIGN KEY (DegreeProgrammeID)
        REFERENCES DegreeProgramme(DegreeProgrammeID),

    CONSTRAINT FK_DegreeInterestMapping_Category
        FOREIGN KEY (InterestCategoryID)
        REFERENCES InterestCategory(InterestCategoryID),

    CONSTRAINT UQ_DegreeInterestMapping
        UNIQUE (DegreeProgrammeID, InterestCategoryID)
);

CREATE TABLE LearnerInterestResponse
(
    LearnerInterestResponseID INT IDENTITY(1,1) PRIMARY KEY,
    LearnerID INT NOT NULL,
    InterestQuestionID INT NOT NULL,
    ResponseValue INT NOT NULL,

    CONSTRAINT FK_LearnerInterestResponse_Learner
        FOREIGN KEY (LearnerID)
        REFERENCES Learner(LearnerID),

    CONSTRAINT FK_LearnerInterestResponse_Question
        FOREIGN KEY (InterestQuestionID)
        REFERENCES InterestQuestion(InterestQuestionID),

    CONSTRAINT CK_LearnerInterestResponse_Value
        CHECK (ResponseValue >= 1 AND ResponseValue <= 5),

    CONSTRAINT UQ_LearnerInterestResponse
        UNIQUE (LearnerID, InterestQuestionID)
);

CREATE TABLE UserAccount
(
    UserAccountID INT IDENTITY(1,1) PRIMARY KEY,
    Username VARCHAR(100) NOT NULL UNIQUE,
    Password VARCHAR(100) NOT NULL,
    RoleName VARCHAR(50) NOT NULL,
    IsActive BIT NOT NULL DEFAULT 1
);

CREATE TABLE FundingOption
(
    FundingOptionID INT IDENTITY(1,1) PRIMARY KEY,
    FundingName VARCHAR(150) NOT NULL,
    FundingType VARCHAR(100) NOT NULL,
    Description VARCHAR(1000),
    IsActive BIT NOT NULL DEFAULT 1
);

CREATE TABLE FundingFaculty
(
    FundingFacultyID INT IDENTITY(1,1) PRIMARY KEY,
    FundingOptionID INT NOT NULL,
    FacultyID INT NOT NULL,

    CONSTRAINT FK_FundingFaculty_Funding
        FOREIGN KEY (FundingOptionID)
        REFERENCES FundingOption(FundingOptionID),

    CONSTRAINT FK_FundingFaculty_Faculty
        FOREIGN KEY (FacultyID)
        REFERENCES Faculty(FacultyID),

    CONSTRAINT UQ_FundingFaculty
        UNIQUE (FundingOptionID, FacultyID)
);

CREATE TABLE AdvisorySession
(
    AdvisorySessionID INT IDENTITY(1,1) PRIMARY KEY,
    LearnerID INT NOT NULL,
    DegreeProgrammeID INT NOT NULL,
    SessionDate DATETIME NOT NULL DEFAULT GETDATE(),

    CONSTRAINT FK_AdvisorySession_Learner
        FOREIGN KEY (LearnerID)
        REFERENCES Learner(LearnerID),

    CONSTRAINT FK_AdvisorySession_Degree
        FOREIGN KEY (DegreeProgrammeID)
        REFERENCES DegreeProgramme(DegreeProgrammeID)
);

CREATE TABLE RecommendationResult
(
    RecommendationResultID INT IDENTITY(1,1) PRIMARY KEY,
    AdvisorySessionID INT NOT NULL,
    Outcome VARCHAR(100) NOT NULL,
    OverallScore DECIMAL(5,2),
    Reason VARCHAR(2000),
    GapInformation VARCHAR(2000),
    AlternativeInformation VARCHAR(2000),

    CONSTRAINT FK_RecommendationResult_Session
        FOREIGN KEY (AdvisorySessionID)
        REFERENCES AdvisorySession(AdvisorySessionID)
);

CREATE TABLE ExportReport
(
    ExportReportID INT IDENTITY(1,1) PRIMARY KEY,
    AdvisorySessionID INT NOT NULL,
    FileName VARCHAR(255) NOT NULL,
    ExportDate DATETIME NOT NULL DEFAULT GETDATE(),

    CONSTRAINT FK_ExportReport_Session
        FOREIGN KEY (AdvisorySessionID)
        REFERENCES AdvisorySession(AdvisorySessionID)
);
GO