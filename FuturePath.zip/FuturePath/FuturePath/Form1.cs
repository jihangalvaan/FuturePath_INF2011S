﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using FuturePath.DataAccess;
using FuturePath.BusinessLogic;
using FuturePath.Entities.Models;

namespace FuturePath
{
    public partial class Form1 : Form
    {

        private LoginService loginService =
    new LoginService();

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            DataTest test = new DataTest();

            if (test.TestConnection())
            {
                MessageBox.Show("Database connection successful!");
            }
            else
            {
                MessageBox.Show("Database connection failed!");
            }
        }

        private void btnLogin_Click(object sender, EventArgs e)
        {
            string username = txtboxUsername.Text.Trim();
            string password = txtboxPassword.Text;

            if (string.IsNullOrWhiteSpace(username))
            {
                MessageBox.Show(
                    "Please enter your username.",
                    "Login",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Warning);

                txtboxUsername.Focus();
                return;
            }

            if (string.IsNullOrWhiteSpace(password))
            {
                MessageBox.Show(
                    "Please enter your password.",
                    "Login",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Warning);

                txtboxPassword.Focus();
                return;
            }

            UserAccount user =
                loginService.Login(
                    username,
                    password);

            if (user == null)
            {
                MessageBox.Show(
                    "Invalid username or password.",
                    "Login",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Warning);

                txtboxPassword.Clear();
                txtboxPassword.Focus();
                return;
            }

            MessageBox.Show(
                "Login successful. Welcome " +
                user.Username + "!",
                "Login",
                MessageBoxButtons.OK,
                MessageBoxIcon.Information);

            if (loginService.IsLearner(user))
            {
                MessageBox.Show(
                    "Learner access granted.",
                    "Access",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Information);
            }
            else if (loginService.IsCareerAdvisor(user))
            {
                MessageBox.Show(
                    "Career Advisor access granted.",
                    "Access",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Information);
            }
            else if (loginService.IsAdministrator(user))
            {
                MessageBox.Show(
                    "System Administrator access granted.",
                    "Access",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Information);
            }
            else
            {
                MessageBox.Show(
                    "Your account does not have a valid role.",
                    "Access",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Warning);
            }
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}