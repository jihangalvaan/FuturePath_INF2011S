﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using FuturePath.Entities.Models;

namespace FuturePath.DataAccess.Repositories
{
    public class DegreeRepository
    {
        private DatabaseHelper databaseHelper = new DatabaseHelper();

        public List<Faculty> GetAllFaculties()
        {
            List<Faculty> faculties = new List<Faculty>();

            string query = @"
                SELECT FacultyID, FacultyName
                FROM Faculty
                ORDER BY FacultyName";

            using (SqlConnection connection = databaseHelper.GetConnection())
            {
                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    connection.Open();

                    using (SqlDataReader reader = command.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            Faculty faculty = new Faculty();

                            faculty.FacultyID =
                                Convert.ToInt32(reader["FacultyID"]);

                            faculty.FacultyName =
                                reader["FacultyName"].ToString();

                            faculties.Add(faculty);
                        }
                    }
                }
            }

            return faculties;
        }

        public List<DegreeProgramme> GetActiveDegreeProgrammes(int facultyID)
        {
            List<DegreeProgramme> programmes =
                new List<DegreeProgramme>();

            string query = @"
                SELECT DegreeProgrammeID,
                       FacultyID,
                       ProgrammeName,
                       IsActive
                FROM DegreeProgramme
                WHERE FacultyID = @FacultyID
                AND IsActive = 1
                ORDER BY ProgrammeName";

            using (SqlConnection connection = databaseHelper.GetConnection())
            {
                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@FacultyID", facultyID);

                    connection.Open();

                    using (SqlDataReader reader = command.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            DegreeProgramme programme =
                                new DegreeProgramme();

                            programme.DegreeProgrammeID =
                                Convert.ToInt32(
                                    reader["DegreeProgrammeID"]);

                            programme.FacultyID =
                                Convert.ToInt32(
                                    reader["FacultyID"]);

                            programme.ProgrammeName =
                                reader["ProgrammeName"].ToString();

                            programme.IsActive =
                                Convert.ToBoolean(
                                    reader["IsActive"]);

                            programmes.Add(programme);
                        }
                    }
                }
            }

            return programmes;
        }

        public DegreeProgramme GetDegreeProgrammeByID(
            int degreeProgrammeID)
        {
            DegreeProgramme programme = null;

            string query = @"
                SELECT DegreeProgrammeID,
                       FacultyID,
                       ProgrammeName,
                       IsActive
                FROM DegreeProgramme
                WHERE DegreeProgrammeID = @DegreeProgrammeID
                AND IsActive = 1";

            using (SqlConnection connection = databaseHelper.GetConnection())
            {
                using (SqlCommand command =
                    new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue(
                        "@DegreeProgrammeID",
                        degreeProgrammeID);

                    connection.Open();

                    using (SqlDataReader reader =
                        command.ExecuteReader())
                    {
                        if (reader.Read())
                        {
                            programme = new DegreeProgramme();

                            programme.DegreeProgrammeID =
                                Convert.ToInt32(
                                    reader["DegreeProgrammeID"]);

                            programme.FacultyID =
                                Convert.ToInt32(
                                    reader["FacultyID"]);

                            programme.ProgrammeName =
                                reader["ProgrammeName"].ToString();

                            programme.IsActive =
                                Convert.ToBoolean(
                                    reader["IsActive"]);
                        }
                    }
                }
            }

            return programme;
        }

        public List<ProgrammeRequirement>
            GetProgrammeRequirements(int degreeProgrammeID)
        {
            List<ProgrammeRequirement> requirements =
                new List<ProgrammeRequirement>();

            string query = @"
                SELECT ProgrammeRequirementID,
                       DegreeProgrammeID,
                       SubjectID,
                       MinimumMark
                FROM ProgrammeRequirement
                WHERE DegreeProgrammeID = @DegreeProgrammeID";

            using (SqlConnection connection =
                databaseHelper.GetConnection())
            {
                using (SqlCommand command =
                    new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue(
                        "@DegreeProgrammeID",
                        degreeProgrammeID);

                    connection.Open();

                    using (SqlDataReader reader =
                        command.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            ProgrammeRequirement requirement =
                                new ProgrammeRequirement();

                            requirement.ProgrammeRequirementID =
                                Convert.ToInt32(
                                    reader["ProgrammeRequirementID"]);

                            requirement.DegreeProgrammeID =
                                Convert.ToInt32(
                                    reader["DegreeProgrammeID"]);

                            requirement.SubjectID =
                                Convert.ToInt32(
                                    reader["SubjectID"]);

                            requirement.MinimumMark =
                                Convert.ToDecimal(
                                    reader["MinimumMark"]);

                            requirements.Add(requirement);
                        }
                    }
                }
            }

            return requirements;
        }
    }
}
