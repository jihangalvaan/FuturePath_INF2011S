﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using FuturePath.Entities.Models;

namespace FuturePath.DataAccess.Repositories
{
    public class InterestRepository
    {
        private DatabaseHelper databaseHelper = new DatabaseHelper();

        public List<InterestCategory> GetAllCategories()
        {
            List<InterestCategory> categories =
                new List<InterestCategory>();

            string query = @"
                SELECT InterestCategoryID, CategoryName
                FROM InterestCategory
                ORDER BY CategoryName";

            using (SqlConnection connection =
                databaseHelper.GetConnection())
            {
                using (SqlCommand command =
                    new SqlCommand(query, connection))
                {
                    connection.Open();

                    using (SqlDataReader reader =
                        command.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            InterestCategory category =
                                new InterestCategory();

                            category.InterestCategoryID =
                                Convert.ToInt32(
                                    reader["InterestCategoryID"]);

                            category.CategoryName =
                                reader["CategoryName"].ToString();

                            categories.Add(category);
                        }
                    }
                }
            }

            return categories;
        }

        public List<InterestQuestion> GetAllQuestions()
        {
            List<InterestQuestion> questions =
                new List<InterestQuestion>();

            string query = @"
                SELECT InterestQuestionID,
                       InterestCategoryID,
                       QuestionText
                FROM InterestQuestion
                ORDER BY InterestQuestionID";

            using (SqlConnection connection =
                databaseHelper.GetConnection())
            {
                using (SqlCommand command =
                    new SqlCommand(query, connection))
                {
                    connection.Open();

                    using (SqlDataReader reader =
                        command.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            InterestQuestion question =
                                new InterestQuestion();

                            question.InterestQuestionID =
                                Convert.ToInt32(
                                    reader["InterestQuestionID"]);

                            question.InterestCategoryID =
                                Convert.ToInt32(
                                    reader["InterestCategoryID"]);

                            question.QuestionText =
                                reader["QuestionText"].ToString();

                            questions.Add(question);
                        }
                    }
                }
            }

            return questions;
        }

        public void SaveLearnerResponse(
            LearnerInterestResponse response)
        {
            string query = @"
                INSERT INTO LearnerInterestResponse
                (LearnerID, InterestQuestionID, ResponseScore)
                VALUES
                (@LearnerID, @InterestQuestionID, @ResponseScore)";

            using (SqlConnection connection =
                databaseHelper.GetConnection())
            {
                using (SqlCommand command =
                    new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue(
                        "@LearnerID",
                        response.LearnerID);

                    command.Parameters.AddWithValue(
                        "@InterestQuestionID",
                        response.InterestQuestionID);

                    command.Parameters.AddWithValue(
                        "@ResponseScore",
                        response.ResponseScore);

                    connection.Open();
                    command.ExecuteNonQuery();
                }
            }
        }

        public List<LearnerInterestResponse>
            GetLearnerResponses(int learnerID)
        {
            List<LearnerInterestResponse> responses =
                new List<LearnerInterestResponse>();

            string query = @"
                SELECT LearnerInterestResponseID,
                       LearnerID,
                       InterestQuestionID,
                       ResponseScore
                FROM LearnerInterestResponse
                WHERE LearnerID = @LearnerID";

            using (SqlConnection connection =
                databaseHelper.GetConnection())
            {
                using (SqlCommand command =
                    new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue(
                        "@LearnerID",
                        learnerID);

                    connection.Open();

                    using (SqlDataReader reader =
                        command.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            LearnerInterestResponse response =
                                new LearnerInterestResponse();

                            response.LearnerInterestResponseID =
                                Convert.ToInt32(
                                    reader["LearnerInterestResponseID"]);

                            response.LearnerID =
                                Convert.ToInt32(
                                    reader["LearnerID"]);

                            response.InterestQuestionID =
                                Convert.ToInt32(
                                    reader["InterestQuestionID"]);

                            response.ResponseScore =
                                Convert.ToInt32(
                                    reader["ResponseScore"]);

                            responses.Add(response);
                        }
                    }
                }
            }

            return responses;
        }

        public List<DegreeInterestMapping>
            GetDegreeInterestMappings(int degreeProgrammeID)
        {
            List<DegreeInterestMapping> mappings =
                new List<DegreeInterestMapping>();

            string query = @"
                SELECT DegreeInterestMappingID,
                       DegreeProgrammeID,
                       InterestCategoryID
                FROM DegreeInterestMapping
                WHERE DegreeProgrammeID = @DegreeProgrammeID";

            using (SqlConnection connection =
                databaseHelper.GetConnection())
            {
                using (SqlCommand command =
                    new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue(
                        "@DegreeProgrammeID",
                        degreeProgrammeID);

                    connection.Open();

                    using (SqlDataReader reader =
                        command.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            DegreeInterestMapping mapping =
                                new DegreeInterestMapping();

                            mapping.DegreeInterestMappingID =
                                Convert.ToInt32(
                                    reader["DegreeInterestMappingID"]);

                            mapping.DegreeProgrammeID =
                                Convert.ToInt32(
                                    reader["DegreeProgrammeID"]);

                            mapping.InterestCategoryID =
                                Convert.ToInt32(
                                    reader["InterestCategoryID"]);

                            mappings.Add(mapping);
                        }
                    }
                }
            }

            return mappings;
        }
    }
}