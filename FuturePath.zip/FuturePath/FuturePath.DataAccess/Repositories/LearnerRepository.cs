﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using FuturePath.Entities.Models;

namespace FuturePath.DataAccess.Repositories
{
    public class LearnerRepository
    {
        private DatabaseHelper databaseHelper = new DatabaseHelper();

        public void AddLearner(Learner learner)
        {
            string query = @"
                INSERT INTO Learner
                (FirstName, Surname, GradeLevelID, School, ContactNumber)
                VALUES
                (@FirstName, @Surname, @GradeLevelID, @School, @ContactNumber)";

            using (SqlConnection connection = databaseHelper.GetConnection())
            {
                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@FirstName", learner.FirstName);
                    command.Parameters.AddWithValue("@Surname", learner.Surname);
                    command.Parameters.AddWithValue("@GradeLevelID", learner.GradeLevelID);
                    command.Parameters.AddWithValue("@School", learner.School);
                    command.Parameters.AddWithValue("@ContactNumber", learner.ContactNumber);

                    connection.Open();
                    command.ExecuteNonQuery();
                }
            }
        }

        public Learner GetLearnerByID(int learnerID)
        {
            Learner learner = null;

            string query = @"
                SELECT LearnerID, FirstName, Surname,
                       GradeLevelID, School, ContactNumber
                FROM Learner
                WHERE LearnerID = @LearnerID";

            using (SqlConnection connection = databaseHelper.GetConnection())
            {
                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@LearnerID", learnerID);

                    connection.Open();

                    using (SqlDataReader reader = command.ExecuteReader())
                    {
                        if (reader.Read())
                        {
                            learner = new Learner();

                            learner.LearnerID =
                                Convert.ToInt32(reader["LearnerID"]);

                            learner.FirstName =
                                reader["FirstName"].ToString();

                            learner.Surname =
                                reader["Surname"].ToString();

                            learner.GradeLevelID =
                                Convert.ToInt32(reader["GradeLevelID"]);

                            learner.School =
                                reader["School"].ToString();

                            learner.ContactNumber =
                                reader["ContactNumber"].ToString();
                        }
                    }
                }
            }

            return learner;
        }

        public List<Learner> GetAllLearners()
        {
            List<Learner> learners = new List<Learner>();

            string query = @"
                SELECT LearnerID, FirstName, Surname,
                       GradeLevelID, School, ContactNumber
                FROM Learner
                ORDER BY Surname, FirstName";

            using (SqlConnection connection = databaseHelper.GetConnection())
            {
                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    connection.Open();

                    using (SqlDataReader reader = command.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            Learner learner = new Learner();

                            learner.LearnerID =
                                Convert.ToInt32(reader["LearnerID"]);

                            learner.FirstName =
                                reader["FirstName"].ToString();

                            learner.Surname =
                                reader["Surname"].ToString();

                            learner.GradeLevelID =
                                Convert.ToInt32(reader["GradeLevelID"]);

                            learner.School =
                                reader["School"].ToString();

                            learner.ContactNumber =
                                reader["ContactNumber"].ToString();

                            learners.Add(learner);
                        }
                    }
                }
            }

            return learners;
        }
    

    public List<LearnerSubject> GetLearnerSubjects(int learnerID)
        {
            List<LearnerSubject> subjects =
                new List<LearnerSubject>();

            string query = @"
        SELECT LearnerSubjectID,
               LearnerID,
               SubjectID,
               Mark
        FROM LearnerSubject
        WHERE LearnerID = @LearnerID
        ORDER BY SubjectID";

            using (SqlConnection connection =
                databaseHelper.GetConnection())
            {
                using (SqlCommand command =
                    new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue(
                        "@LearnerID",
                        learnerID);

                    connection.Open();

                    using (SqlDataReader reader =
                        command.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            LearnerSubject learnerSubject =
                                new LearnerSubject();

                            learnerSubject.LearnerSubjectID =
                                Convert.ToInt32(
                                    reader["LearnerSubjectID"]);

                            learnerSubject.LearnerID =
                                Convert.ToInt32(
                                    reader["LearnerID"]);

                            learnerSubject.SubjectID =
                                Convert.ToInt32(
                                    reader["SubjectID"]);

                            learnerSubject.Mark =
                                Convert.ToDecimal(
                                    reader["Mark"]);

                            subjects.Add(learnerSubject);
                        }
                    }
                }
            }

            return subjects;
        }
    }
}