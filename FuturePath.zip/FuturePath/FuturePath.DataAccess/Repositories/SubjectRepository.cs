﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using FuturePath.Entities.Models;

namespace FuturePath.DataAccess.Repositories
{
    public class SubjectRepository
    {
        private DatabaseHelper databaseHelper = new DatabaseHelper();

        public List<Subject> GetAllSubjects()
        {
            List<Subject> subjects = new List<Subject>();

            string query = @"
                SELECT SubjectID, SubjectName
                FROM Subject
                ORDER BY SubjectName";

            using (SqlConnection connection = databaseHelper.GetConnection())
            {
                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    connection.Open();

                    using (SqlDataReader reader = command.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            Subject subject = new Subject();

                            subject.SubjectID =
                                Convert.ToInt32(reader["SubjectID"]);

                            subject.SubjectName =
                                reader["SubjectName"].ToString();

                            subjects.Add(subject);
                        }
                    }
                }
            }

            return subjects;
        }

        public Subject GetSubjectByID(int subjectID)
        {
            Subject subject = null;

            string query = @"
                SELECT SubjectID, SubjectName
                FROM Subject
                WHERE SubjectID = @SubjectID";

            using (SqlConnection connection = databaseHelper.GetConnection())
            {
                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@SubjectID", subjectID);

                    connection.Open();

                    using (SqlDataReader reader = command.ExecuteReader())
                    {
                        if (reader.Read())
                        {
                            subject = new Subject();

                            subject.SubjectID =
                                Convert.ToInt32(reader["SubjectID"]);

                            subject.SubjectName =
                                reader["SubjectName"].ToString();
                        }
                    }
                }
            }

            return subject;
        }
    }
}