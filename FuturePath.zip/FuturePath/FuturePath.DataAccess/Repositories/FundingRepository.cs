﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using FuturePath.Entities.Models;

namespace FuturePath.DataAccess.Repositories
{
    public class FundingRepository
    {
        private DatabaseHelper databaseHelper = new DatabaseHelper();

        public List<FundingOption> GetActiveFundingOptions()
        {
            List<FundingOption> fundingOptions =
                new List<FundingOption>();

            string query = @"
                SELECT FundingOptionID,
                       FundingName,
                       FundingType,
                       Description,
                       IsActive
                FROM FundingOption
                WHERE IsActive = 1
                ORDER BY FundingName";

            using (SqlConnection connection =
                databaseHelper.GetConnection())
            {
                using (SqlCommand command =
                    new SqlCommand(query, connection))
                {
                    connection.Open();

                    using (SqlDataReader reader =
                        command.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            FundingOption fundingOption =
                                new FundingOption();

                            fundingOption.FundingOptionID =
                                Convert.ToInt32(
                                    reader["FundingOptionID"]);

                            fundingOption.FundingName =
                                reader["FundingName"].ToString();

                            fundingOption.FundingType =
                                reader["FundingType"].ToString();

                            fundingOption.Description =
                                reader["Description"].ToString();

                            fundingOption.IsActive =
                                Convert.ToBoolean(
                                    reader["IsActive"]);

                            fundingOptions.Add(fundingOption);
                        }
                    }
                }
            }

            return fundingOptions;
        }

        public FundingOption GetFundingOptionByID(
            int fundingOptionID)
        {
            FundingOption fundingOption = null;

            string query = @"
                SELECT FundingOptionID,
                       FundingName,
                       FundingType,
                       Description,
                       IsActive
                FROM FundingOption
                WHERE FundingOptionID = @FundingOptionID
                AND IsActive = 1";

            using (SqlConnection connection =
                databaseHelper.GetConnection())
            {
                using (SqlCommand command =
                    new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue(
                        "@FundingOptionID",
                        fundingOptionID);

                    connection.Open();

                    using (SqlDataReader reader =
                        command.ExecuteReader())
                    {
                        if (reader.Read())
                        {
                            fundingOption =
                                new FundingOption();

                            fundingOption.FundingOptionID =
                                Convert.ToInt32(
                                    reader["FundingOptionID"]);

                            fundingOption.FundingName =
                                reader["FundingName"].ToString();

                            fundingOption.FundingType =
                                reader["FundingType"].ToString();

                            fundingOption.Description =
                                reader["Description"].ToString();

                            fundingOption.IsActive =
                                Convert.ToBoolean(
                                    reader["IsActive"]);
                        }
                    }
                }
            }

            return fundingOption;
        }
    }
}
