﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using FuturePath.Entities.Models;

namespace FuturePath.DataAccess.Repositories
{
    public class AdvisoryRepository
    {
        private DatabaseHelper databaseHelper = new DatabaseHelper();

        public int CreateAdvisorySession(AdvisorySession session)
        {
            string query = @"
                INSERT INTO AdvisorySession
                (LearnerID, DegreeProgrammeID, SessionDate)
                VALUES
                (@LearnerID, @DegreeProgrammeID, @SessionDate);

                SELECT CAST(SCOPE_IDENTITY() AS INT);";

            using (SqlConnection connection =
                databaseHelper.GetConnection())
            {
                using (SqlCommand command =
                    new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue(
                        "@LearnerID",
                        session.LearnerID);

                    command.Parameters.AddWithValue(
                        "@DegreeProgrammeID",
                        session.DegreeProgrammeID);

                    command.Parameters.AddWithValue(
                        "@SessionDate",
                        session.SessionDate);

                    connection.Open();

                    return Convert.ToInt32(
                        command.ExecuteScalar());
                }
            }
        }

        public void SaveRecommendationResult(
            RecommendationResult result)
        {
            string query = @"
                INSERT INTO RecommendationResult
                (AdvisorySessionID,
                 Outcome,
                 RecommendationScore,
                 Reason,
                 AcademicGap)
                VALUES
                (@AdvisorySessionID,
                 @Outcome,
                 @RecommendationScore,
                 @Reason,
                 @AcademicGap)";

            using (SqlConnection connection =
                databaseHelper.GetConnection())
            {
                using (SqlCommand command =
                    new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue(
                        "@AdvisorySessionID",
                        result.AdvisorySessionID);

                    command.Parameters.AddWithValue(
                        "@Outcome",
                        result.Outcome);

                    command.Parameters.AddWithValue(
                        "@RecommendationScore",
                        result.RecommendationScore);

                    command.Parameters.AddWithValue(
                        "@Reason",
                        result.Reason);

                    command.Parameters.AddWithValue(
                        "@AcademicGap",
                        result.AcademicGap);

                    connection.Open();
                    command.ExecuteNonQuery();
                }
            }
        }

        public RecommendationResult
            GetRecommendationResult(int advisorySessionID)
        {
            RecommendationResult result = null;

            string query = @"
                SELECT RecommendationResultID,
                       AdvisorySessionID,
                       Outcome,
                       RecommendationScore,
                       Reason,
                       AcademicGap
                FROM RecommendationResult
                WHERE AdvisorySessionID = @AdvisorySessionID";

            using (SqlConnection connection =
                databaseHelper.GetConnection())
            {
                using (SqlCommand command =
                    new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue(
                        "@AdvisorySessionID",
                        advisorySessionID);

                    connection.Open();

                    using (SqlDataReader reader =
                        command.ExecuteReader())
                    {
                        if (reader.Read())
                        {
                            result = new RecommendationResult();

                            result.RecommendationResultID =
                                Convert.ToInt32(
                                    reader["RecommendationResultID"]);

                            result.AdvisorySessionID =
                                Convert.ToInt32(
                                    reader["AdvisorySessionID"]);

                            result.Outcome =
                                reader["Outcome"].ToString();

                            result.RecommendationScore =
                                Convert.ToDecimal(
                                    reader["RecommendationScore"]);

                            result.Reason =
                                reader["Reason"].ToString();

                            result.AcademicGap =
                                reader["AcademicGap"].ToString();
                        }
                    }
                }
            }

            return result;
        }

        public void SaveExportReport(ExportReport report)
        {
            string query = @"
                INSERT INTO ExportReport
                (AdvisorySessionID,
                 ReportType,
                 ExportDate,
                 FilePath)
                VALUES
                (@AdvisorySessionID,
                 @ReportType,
                 @ExportDate,
                 @FilePath)";

            using (SqlConnection connection =
                databaseHelper.GetConnection())
            {
                using (SqlCommand command =
                    new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue(
                        "@AdvisorySessionID",
                        report.AdvisorySessionID);

                    command.Parameters.AddWithValue(
                        "@ReportType",
                        report.ReportType);

                    command.Parameters.AddWithValue(
                        "@ExportDate",
                        report.ExportDate);

                    command.Parameters.AddWithValue(
                        "@FilePath",
                        report.FilePath);

                    connection.Open();
                    command.ExecuteNonQuery();
                }
            }
        }
    }
}