﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using FuturePath.Entities.Models;

namespace FuturePath.DataAccess.Repositories
{
    public class UserRepository
    {
        private DatabaseHelper databaseHelper = new DatabaseHelper();

        public UserAccount Login(string username, string password)
        {
            UserAccount user = null;

            string query = @"
                SELECT UserAccountID, Username, Password, Role, IsActive
                FROM UserAccount
                WHERE Username = @Username
                AND Password = @Password
                AND IsActive = 1";

            using (SqlConnection connection = databaseHelper.GetConnection())
            {
                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@Username", username);
                    command.Parameters.AddWithValue("@Password", password);

                    connection.Open();

                    using (SqlDataReader reader = command.ExecuteReader())
                    {
                        if (reader.Read())
                        {
                            user = new UserAccount();

                            user.UserAccountID = Convert.ToInt32(reader["UserAccountID"]);
                            user.Username = reader["Username"].ToString();
                            user.Password = reader["Password"].ToString();
                            user.Role = reader["Role"].ToString();
                            user.IsActive = Convert.ToBoolean(reader["IsActive"]);
                        }
                    }
                }
            }

            return user;
        }
    }
}
