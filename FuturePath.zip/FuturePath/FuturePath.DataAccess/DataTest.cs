﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;

namespace FuturePath.DataAccess
{
    public class DataTest
    {
        public bool TestConnection()
        {
            try
            {
                DatabaseHelper db = new DatabaseHelper();

                using (SqlConnection connection = db.GetConnection())
                {
                    connection.Open();
                    return true;
                }
            }
            catch
            {
                return false;
            }
        }
    }
}